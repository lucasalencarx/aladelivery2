import {
  ExternalLink,
  Menu,
  Clock3,
} from "lucide-react";

import { useAdmin } from "../context/AdminContext";

export default function AdminHeader() {
  const {
    storeOpen,
    toggleStore,
    setSidebarOpen,
    changingStoreStatus,
    storeStatus,
    loadingStoreStatus,
    enableAutomaticStoreStatus,
  } = useAdmin();

  async function handleStoreStatus() {
    const result = await toggleStore();

    if (!result?.success) {
      alert(
        "Não foi possível alterar o status da loja."
      );
    }
  }

  function formatTime(time) {
    if (!time) return "--:--";

    return time.substring(0, 5);
  }

  function formatDateTime(date) {
    if (!date) return null;

    return new Intl.DateTimeFormat(
      "pt-BR",
      {
        timeZone: "America/Sao_Paulo",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }
    ).format(new Date(date));
  }

  const lastChange = storeOpen
    ? storeStatus?.last_opened_at
    : storeStatus?.last_closed_at;

  return (
    <header className="adminTopbar">

      <button
        type="button"
        className="adminMobileMenu"
        onClick={() => setSidebarOpen(true)}
        aria-label="Abrir menu"
      >
        <Menu size={21} />
      </button>

      <div className="adminGreeting">
        <h1>Olá, Lucas!</h1>

        <p>
          Bem-vindo ao painel administrativo
        </p>
      </div>

      <div className="adminTopActions">

        {/* =========================================
            STATUS DA LOJA
        ========================================= */}

        <div className="storeStateCompact">

          <div className="storeStateInfo">

            <div className="storeStateMain">

              <span
                className={`storeDot ${
                  storeOpen
                    ? "open"
                    : "closed"
                }`}
              />

              <strong>
                {loadingStoreStatus
                  ? "Carregando..."
                  : changingStoreStatus
                  ? "Alterando..."
                  : storeOpen
                    ? "Loja aberta"
                    : "Loja fechada"}
              </strong>

            </div>

            {/* MENSAGEM DO BANCO */}

            {!storeOpen &&
              storeStatus?.closed_message && (
                <span className="storeClosedMessage">
                  {storeStatus.closed_message}
                </span>
              )}

            {/* HORÁRIO */}

            <div className="storeScheduleInfo">

              <Clock3 size={11} />

              <span>
                {formatTime(
                  storeStatus?.opening_time
                )}
                {" até "}
                {formatTime(
                  storeStatus?.closing_time
                )}
              </span>

            </div>

            {/* ÚLTIMA ALTERAÇÃO */}

            {lastChange && (
              <span className="storeLastChange">

                {storeOpen
                  ? "Aberta em "
                  : "Fechada em "}

                {formatDateTime(lastChange)}

              </span>
            )}

          </div>

          {/* SWITCH */}

          <button
            type="button"
            className={`miniSwitch ${
              storeOpen
                ? "active"
                : ""
            }`}
            onClick={handleStoreStatus}
            disabled={changingStoreStatus || loadingStoreStatus}
            aria-label={
              storeOpen
                ? "Fechar loja"
                : "Abrir loja"
            }
          >
            <span />
          </button>

          {/* MODO MANUAL */}

          {storeStatus?.manual_override && (
            <button type="button" className="storeManualBadge" disabled={changingStoreStatus} onClick={async () => { const result = await enableAutomaticStoreStatus(); if (!result?.success) alert("Não foi possível aplicar o horário automático."); }} title="Voltar ao horário automático">
              Manual · usar horário
            </button>
          )}

        </div>

        {/* =========================================
            VER LOJA
        ========================================= */}

        <button
          type="button"
          className="adminGhostButton"
          onClick={() =>
            window.open(
              "/",
              "_blank",
              "noopener,noreferrer"
            )
          }
        >
          Ver loja

          <ExternalLink size={13} />
        </button>

        {/* =========================================
            LOGO
        ========================================= */}

        <div className="adminMiniBrand">

          <div className="adminMiniBrandIcon">
            A
          </div>

          <strong>AlaDelivery</strong>

        </div>

      </div>

    </header>
  );
}