import OrderAlerts from './OrderAlerts';
import { Outlet } from "react-router-dom";
import { AdminProvider } from "../context/AdminContext";
import AdminSidebar from "./AdminSidebar";
import AdminHeader from "./AdminHeader";
import logoMarca from "../../assets/images/logomarca.png";
import "./admin.css";
import "./management.css";
import AdminAccessGate from "./AdminAccessGate";

export default function AdminLayout() {
  return (
    <AdminAccessGate><AdminProvider>
      <div className="alaAdmin">
        <AdminSidebar />

        <div className="alaAdminMain">
          <AdminHeader />

          <main className="alaAdminContent">
            <OrderAlerts />
            <Outlet />
          </main>
        </div>
      </div>
    </AdminProvider></AdminAccessGate>
  );
}
