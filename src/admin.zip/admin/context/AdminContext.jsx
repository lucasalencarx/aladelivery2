import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";

import { supabase } from "../../supabase/supabase";

const AdminContext = createContext(null);

export function AdminProvider({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [storeStatus, setStoreStatus] = useState(null);

  const [storeOpen, setStoreOpen] = useState(false);

  const [loadingStoreStatus, setLoadingStoreStatus] =
    useState(true);

  const [changingStoreStatus, setChangingStoreStatus] =
    useState(false);

  // =====================================================
  // CONVERTER HH:MM:SS PARA MINUTOS
  // =====================================================

  function timeToMinutes(time) {
    if (!time) return 0;

    const [hours, minutes] = time
      .split(":")
      .map(Number);

    return hours * 60 + minutes;
  }

  // =====================================================
  // CALCULAR SE A LOJA ESTÁ ABERTA PELO HORÁRIO
  // =====================================================

  const calculateAutomaticStatus = useCallback(
    (status) => {
      if (!status) return false;

      const opening =
        timeToMinutes(status.opening_time);

      const closing =
        timeToMinutes(status.closing_time);

      const now = new Date();

      const current =
        now.getHours() * 60 + now.getMinutes();

      // ---------------------------------------------
      // EXEMPLO:
      // 08:00 até 23:00
      // ---------------------------------------------

      if (opening < closing) {
        return (
          current >= opening &&
          current < closing
        );
      }

      // ---------------------------------------------
      // HORÁRIO ATRAVESSA MEIA-NOITE
      //
      // Ex:
      // 18:00 até 02:00
      //
      // ou
      //
      // 08:00 até 00:00
      // ---------------------------------------------

      if (opening > closing) {
        return (
          current >= opening ||
          current < closing
        );
      }

      // ---------------------------------------------
      // abertura === fechamento
      //
      // Você pode interpretar como 24h.
      // ---------------------------------------------

      return true;
    },
    []
  );

  // =====================================================
  // DETERMINAR STATUS REAL
  // =====================================================

  const resolveStoreStatus = useCallback(
    (status) => {
      if (!status) return false;

      // ---------------------------------------------
      // CONTROLE MANUAL
      // ---------------------------------------------

      if (status.manual_override) {
        return status.is_open;
      }

      // ---------------------------------------------
      // CONTROLE AUTOMÁTICO
      // ---------------------------------------------

      return calculateAutomaticStatus(status);
    },
    [calculateAutomaticStatus]
  );

  // =====================================================
  // CARREGAR CONFIGURAÇÃO DA LOJA
  // =====================================================

  const loadStoreStatus = useCallback(
    async () => {
      try {
        setLoadingStoreStatus(true);

        const {
          data,
          error,
        } = await supabase
          .from("store_status")
          .select("*")
          .eq("id", 1)
          .single();

        if (error) {
          throw error;
        }

        setStoreStatus(data);

        const opened =
          resolveStoreStatus(data);

        setStoreOpen(opened);
      } catch (error) {
        console.error(
          "Erro ao carregar status da loja:",
          error
        );

        setStoreOpen(false);
      } finally {
        setLoadingStoreStatus(false);
      }
    },
    [resolveStoreStatus]
  );

  // =====================================================
  // ABRIR LOJA MANUALMENTE
  // =====================================================

async function openStore() {
  if (changingStoreStatus) return;

  try {
    setChangingStoreStatus(true);

    const { data, error } = await supabase
      .from("store_status")
      .update({
        is_open: true,
        manual_override: true,
      })
      .eq("id", 1)
      .select()
      .single();

    if (error) {
      throw error;
    }

    setStoreStatus(data);
    setStoreOpen(true);

    return {
      success: true,
      data,
    };

  } catch (error) {
    console.error("Erro ao abrir loja:", error);

    return {
      success: false,
      error,
    };

  } finally {
    setChangingStoreStatus(false);
  }
}

  // =====================================================
  // FECHAR LOJA MANUALMENTE
  // =====================================================

async function closeStore() {
  if (changingStoreStatus) return;

  try {
    setChangingStoreStatus(true);

    const { data, error } = await supabase
      .from("store_status")
      .update({
        is_open: false,
        manual_override: true,
      })
      .eq("id", 1)
      .select()
      .single();

    if (error) {
      throw error;
    }

    setStoreStatus(data);
    setStoreOpen(false);

    return {
      success: true,
      data,
    };

  } catch (error) {
    console.error("Erro ao fechar loja:", error);

    return {
      success: false,
      error,
    };

  } finally {
    setChangingStoreStatus(false);
  }
}

  // =====================================================
  // ALTERNAR STATUS MANUAL
  // =====================================================

  async function toggleStore() {
    if (storeOpen) {
      return await closeStore();
    }

    return await openStore();
  }

  // =====================================================
  // VOLTAR AO HORÁRIO AUTOMÁTICO
  // =====================================================

  async function enableAutomaticStoreStatus() {
    if (changingStoreStatus) return;

    try {
      setChangingStoreStatus(true);

      const {
        data,
        error,
      } = await supabase
        .from("store_status")
        .update({
          manual_override: false,
        })
        .eq("id", 1)
        .select()
        .single();

      if (error) {
        throw error;
      }

      setStoreStatus(data);

      const opened =
        resolveStoreStatus(data);

      setStoreOpen(opened);

      return {
        success: true,
      };
    } catch (error) {
      console.error(
        "Erro ao ativar modo automático:",
        error
      );

      return {
        success: false,
        error,
      };
    } finally {
      setChangingStoreStatus(false);
    }
  }

  // =====================================================
  // ATUALIZAR HORÁRIOS
  // =====================================================

  async function updateStoreSchedule({
    openingTime,
    closingTime,
    closedMessage,
  }) {
    try {
      setChangingStoreStatus(true);

      const {
        data,
        error,
      } = await supabase
        .from("store_status")
        .update({
          opening_time: openingTime,
          closing_time: closingTime,
          closed_message: closedMessage,
        })
        .eq("id", 1)
        .select()
        .single();

      if (error) {
        throw error;
      }

      setStoreStatus(data);

      const opened =
        resolveStoreStatus(data);

      setStoreOpen(opened);

      return {
        success: true,
      };
    } catch (error) {
      console.error(
        "Erro ao atualizar horário:",
        error
      );

      return {
        success: false,
        error,
      };
    } finally {
      setChangingStoreStatus(false);
    }
  }

  // =====================================================
  // CARREGAMENTO INICIAL
  // =====================================================

  useEffect(() => {
    loadStoreStatus();
  }, [loadStoreStatus]);

  // =====================================================
  // VERIFICAR HORÁRIO A CADA 30 SEGUNDOS
  // =====================================================

  useEffect(() => {
    const interval = setInterval(() => {
      if (
        storeStatus &&
        !storeStatus.manual_override
      ) {
        setStoreOpen(
          resolveStoreStatus(storeStatus)
        );
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [
    storeStatus,
    resolveStoreStatus,
  ]);

  return (
    <AdminContext.Provider
      value={{
        sidebarOpen,
        setSidebarOpen,

        storeStatus,

        storeOpen,
        setStoreOpen,

        loadingStoreStatus,
        changingStoreStatus,

        loadStoreStatus,

        openStore,
        closeStore,
        toggleStore,

        enableAutomaticStoreStatus,

        updateStoreSchedule,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const context =
    useContext(AdminContext);

  if (!context) {
    throw new Error(
      "useAdmin deve ser usado dentro de AdminProvider"
    );
  }

  return context;
}