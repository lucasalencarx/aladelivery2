import PlaceholderPage from "../components/PlaceholderPage";

export default function AdminSettings() {
  return (
    <PlaceholderPage
      title="Configurações"
      description="Defina regras gerais, horários, entrega e comportamento do sistema."
      icon="⚙️"
    />
  );
}
