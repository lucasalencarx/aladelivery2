import PlaceholderPage from "../components/PlaceholderPage";

export default function AdminOffers() {
  return (
    <PlaceholderPage
      title="Ofertas e Seções"
      description="Gerencie promoções, vitrines, seções e produtos em destaque."
      icon="🏷️"
    />
  );
}
