import PageHeader from "../components/PageHeader";
import SimpleAdminTable from "../components/SimpleAdminTable";
import { topCustomers } from "../data/dashboardData";

function money(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export default function AdminCustomers() {
  return (
    <section className="adminPage">
      <PageHeader
        eyebrow="Relacionamento"
        title="Clientes"
        description="Visualize clientes, pedidos e histórico de compras."
      />

      <SimpleAdminTable
        rows={topCustomers.map((item, index) => ({
          id: index + 1,
          ...item,
          phone: `(21) 99${index + 1}11-22${index + 1}${index}`,
        }))}
        columns={[
          { key: "name", label: "Cliente" },
          { key: "phone", label: "Telefone" },
          { key: "orders", label: "Pedidos" },
          {
            key: "revenue",
            label: "Total comprado",
            render: (value) => <strong>{money(value)}</strong>,
          },
        ]}
      />
    </section>
  );
}
