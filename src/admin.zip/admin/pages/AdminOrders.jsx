import { useMemo, useState } from "react";
import { Eye, Search } from "lucide-react";
import PageHeader from "../components/PageHeader";
import SimpleAdminTable from "../components/SimpleAdminTable";
import StatusBadge from "../components/StatusBadge";
import { realtimeOrders } from "../data/dashboardData";

function money(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export default function AdminOrders() {
  const [query, setQuery] = useState("");

  const rows = useMemo(
    () =>
      realtimeOrders.filter((order) =>
        `${order.id} ${order.customer} ${order.status}`
          .toLowerCase()
          .includes(query.toLowerCase())
      ),
    [query]
  );

  return (
    <section className="adminPage">
      <PageHeader
        eyebrow="Operação"
        title="Pedidos"
        description="Acompanhe pedidos, pagamentos e andamento das entregas."
      />

      <div className="adminToolbar">
        <label className="adminSearch">
          <Search size={16} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar pedido, cliente ou status..."
          />
        </label>

        <button type="button" className="adminPrimaryButton">
          Atualizar pedidos
        </button>
      </div>

      <SimpleAdminTable
        rows={rows}
        columns={[
          { key: "id", label: "Pedido" },
          { key: "customer", label: "Cliente" },
          {
            key: "status",
            label: "Status",
            render: (value) => <StatusBadge>{value}</StatusBadge>,
          },
          {
            key: "items",
            label: "Itens",
            render: (value) => `${value} item(ns)`,
          },
          {
            key: "total",
            label: "Total",
            render: (value) => <strong>{money(value)}</strong>,
          },
          { key: "time", label: "Horário" },
          {
            key: "action",
            label: "",
            render: () => (
              <button type="button" className="tableIconButton">
                <Eye size={16} />
              </button>
            ),
          },
        ]}
      />
    </section>
  );
}
