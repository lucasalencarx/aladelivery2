import {
  Banknote,
  CalendarDays,
  CreditCard,
  PackageCheck,
  Star,
  Users,
} from "lucide-react";

import MetricCard from "../components/MetricCard";
import MiniLineChart from "../components/MiniLineChart";
import PaymentDonut from "../components/PaymentDonut";
import QuickActions from "../components/QuickActions";
import RankingList from "../components/RankingList";
import RealtimeOrders from "../components/RealtimeOrders";
import StoreAddressCard from "../components/StoreAddressCard";
import StoreStatusCard from "../components/StoreStatusCard";

import {
  dashboardMetrics,
  overviewData,
  paymentData,
  realtimeOrders,
  topCustomers,
  topProducts,
} from "../data/dashboardData";

function money(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export default function AdminDashboard() {
  const metrics = dashboardMetrics;

  return (
    <section className="adminDashboardPage">
      <div className="dashboardTopGrid">
        <StoreStatusCard />
        <StoreAddressCard />

        <MetricCard
          title="Pedidos Hoje"
          value={metrics.ordersToday}
          growth={metrics.ordersGrowth}
        />

        <MetricCard
          title="Faturamento Hoje"
          value={metrics.revenueToday}
          growth={metrics.revenueGrowth}
          moneyValue
        />

        <MetricCard
          title="Ticket Médio"
          value={metrics.averageTicket}
          growth={metrics.ticketGrowth}
          moneyValue
        />

        <MetricCard
          title="Visitantes Hoje"
          value={metrics.visitorsToday}
          growth={metrics.visitorsGrowth}
        />
      </div>

      <div className="dashboardMainGrid">
        <div className="dashboardLeft">
          <div className="dashboardAnalyticsGrid">
            <article className="dashboardCard overviewCard">
              <div className="cardHeadingRow">
                <strong>Visão Geral</strong>

                <div className="chartTabs">
                  <button type="button" className="active">Hoje</button>
                  <button type="button">7 dias</button>
                  <button type="button">30 dias</button>
                  <button type="button">Este mês</button>
                </div>
              </div>

              <MiniLineChart
                data={overviewData}
                primaryKey="revenue"
                secondaryKey="orders"
                labels={["00:00", "04:00", "08:00", "12:00", "16:00", "20:00", "23:59"]}
              />

              <div className="chartLegend">
                <span><i className="yellow" /> Faturamento (R$)</span>
                <span><i className="black" /> Pedidos</span>
              </div>
            </article>

            <article className="dashboardCard paymentCard">
              <strong className="dashboardCardTitle">Formas de Pagamento</strong>
              <PaymentDonut data={paymentData} />
            </article>
          </div>

          <div className="dashboardBottomGrid">
            <RankingList
              title="Produtos Mais Vendidos"
              items={topProducts}
              type="product"
              buttonLabel="Ver todos os produtos"
            />

            <RankingList
              title="Clientes que Mais Compram"
              items={topCustomers}
              type="customer"
              buttonLabel="Ver todos os clientes"
            />

            <article className="dashboardCard visitorsCard">
              <strong className="dashboardCardTitle">Visitas ao Site / App</strong>

              <MiniLineChart
                data={overviewData.map((item, index) => ({
                  ...item,
                  visitors: Math.max(
                    40,
                    Math.round(item.revenue / 3.4 + (index % 3) * 60)
                  ),
                }))}
                primaryKey="visitors"
                labels={["00:00", "06:00", "12:00", "18:00", "23:59"]}
              />

              <div className="visitorsTotalBox">
                <span>Total de visitantes</span>
                <strong>842 <b>↗ 15%</b></strong>
                <small>em relação a ontem</small>
              </div>

              <button type="button" className="fullSoftButton">
                Ver relatório completo
              </button>
            </article>
          </div>

          <article className="dashboardCard daySummary">
            <strong className="dashboardCardTitle">Resumo do Dia</strong>

            <div className="daySummaryGrid">
              <SummaryItem icon={CalendarDays} value="128" label="Pedidos" />
              <SummaryItem icon={PackageCheck} value={money(2458.9)} label="Faturamento" />
              <SummaryItem icon={Banknote} value={money(19.21)} label="Ticket Médio" />
              <SummaryItem icon={Users} value="842" label="Visitantes" />
              <SummaryItem icon={CreditCard} value={money(614.72)} label="Recebimentos (Cartão)" />
              <SummaryItem icon={Banknote} value={money(1598.29)} label="Recebimentos (PIX)" />
              <SummaryItem icon={Star} value="12" label="Avaliações" />
            </div>
          </article>
        </div>

        <aside className="dashboardRight">
          <RealtimeOrders orders={realtimeOrders} />
          <QuickActions />
        </aside>
      </div>
    </section>
  );
}

function SummaryItem({ icon: Icon, value, label }) {
  return (
    <div className="daySummaryItem">
      <span className="daySummaryIcon">
        <Icon size={16} />
      </span>

      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}
