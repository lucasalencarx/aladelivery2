import PlaceholderPage from "../components/PlaceholderPage";

export default function AdminCouriers() {
  return (
    <PlaceholderPage
      title="Entregadores"
      description="Gerencie entregadores, disponibilidade e entregas em andamento."
      icon="🛵"
    />
  );
}
