import PlaceholderPage from "../components/PlaceholderPage";

export default function AdminReviews() {
  return (
    <PlaceholderPage
      title="Avaliações"
      description="Acompanhe notas e comentários dos clientes."
      icon="⭐"
    />
  );
}
