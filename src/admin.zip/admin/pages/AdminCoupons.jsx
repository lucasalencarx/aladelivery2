import PlaceholderPage from "../components/PlaceholderPage";

export default function AdminCoupons() {
  return (
    <PlaceholderPage
      title="Cupons"
      description="Crie cupons, regras de desconto e campanhas promocionais."
      icon="🎟️"
    />
  );
}
