import { Outlet } from "react-router-dom";
import { AdminProvider } from "../context/AdminContext";
import AdminSidebar from "./AdminSidebar";
import AdminHeader from "./AdminHeader";
import logoMarca from "../../assets/images/logomarca.png";
import "./admin.css";

export default function AdminLayout() {
  return (
    <AdminProvider>
      <div className="alaAdmin">
        <AdminSidebar />

        <div className="alaAdminMain">
          <AdminHeader />

          <main className="alaAdminContent">
            <Outlet />
          </main>
        </div>
      </div>
    </AdminProvider>
  );
}
